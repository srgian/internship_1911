#ifndef WIFICONN_H
#define WIFICONN_H

#include <Arduino.h>
#include <inttypes.h>

void infoPgLights();
void infoPgConfort();
void connToWifi();


#endif // WIFICONN_H
