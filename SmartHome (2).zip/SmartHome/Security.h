#ifndef SECURITY_H
#define SECURITY_H
#include <inttypes.h>


void SecurityInit();
void SecurityMainFunction();




#endif
