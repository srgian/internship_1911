#ifndef LOGIC_H
#define LOGIC_H

void MainFunction();

#endif // LOGIC_H
