void ComfortInit();

void ComfortMainFunction();
