#include "Logic.h"
#include "Lights.h"
#include "Comfort.h"
#include  "Security.h"
#include "Doorlock.h"

void MainFunction()
{
    //LightsMainFunction();
    //ComfortMainFunction();
    SecurityMainFunction();
   DoorlockMainFunction();
}
