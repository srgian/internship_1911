#ifndef DOORLOCK_H
#define DOORLOCK_H
#include <inttypes.h>


void DoorlockInit();
void DoorlockMainFunction();



#endif
